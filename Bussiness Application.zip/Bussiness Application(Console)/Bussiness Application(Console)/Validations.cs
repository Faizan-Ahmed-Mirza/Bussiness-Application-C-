﻿using Bussiness_Application.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application
{
    public class Validations
    {
        public static double get_double_input()
        {
            string sample_input = Validations.check_if_input_include_special_char(',');
            double value_to_return = 0;
            for (int i = 0; i < sample_input.Length; i++)
            {
                char index = sample_input[i];
                if(index != '0' && index != '1' && index != '2' && index != '3' && index != '4' && index != '5' && index != '6' && index != '7' && index != '8' && index != '9'&& index != '.')
                {
                    Console.WriteLine("Please enter numerical value only.");
                    Program_UI.pause();
                    value_to_return = get_double_input();
                    return value_to_return;
                }
            }

            return double.Parse(sample_input);
        }


        


        public static string check_if_input_include_special_char(char special_char)
        {
            string sample;
            string string_to_return;
            sample = Console.ReadLine();

            for (int i = 0; i < sample.Length; i++)
            {
                if(sample[i] == special_char)
                {
                    Console.WriteLine($"Input can not include '{special_char}'");
                    Program_UI.pause();
                    string_to_return = check_if_input_include_special_char(special_char);
                    return string_to_return;
                }
            }

            return sample;
        }




        public static string get_field(int field_number, char seperation_char ,string line)
        {
            int char_count = 0;
            string string_to_return = "";
            for (int i = 0; i < line.Length; i++)
            {
                if(line[i] == seperation_char)
                {
                    char_count++;
                }
                else if(char_count == field_number - 1)
                {
                    string_to_return = string_to_return + line[i];
                }
                else if(char_count >= field_number)
                {
                    break;
                }
            }
            return string_to_return;
        }


    }
}
