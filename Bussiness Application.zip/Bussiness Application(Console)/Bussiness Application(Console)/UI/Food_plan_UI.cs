﻿using Bussiness_Application.BL;
using Bussiness_Application.DL;
using Bussiness_Application_Console_.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.UI
{
    public class Food_plan_UI
    {
        // Show Food plans
        public static void show_food_plans()
        {
            Console.WriteLine("Plan name                Breakfast            Lunch              Dinner              Price");
            foreach (Food_plan food_plan_of_iteration in Food_plan_DL.food_plans_available)
            {
                Console.WriteLine($"{food_plan_of_iteration.Name}                {food_plan_of_iteration.Break_fast.Name}             {food_plan_of_iteration.Lunch.Name}              {food_plan_of_iteration.Dinner.Name}               {food_plan_of_iteration.get_total_price()}");
            }
            Console.WriteLine("\n");
        }



        // Add new Food Plan
        public static void add_new_food_plan()
        {
            Program_UI.clear_screen();
            Food_plan food_plan_to_add = new Food_plan();
            Console.WriteLine("           Add new Food Plan\n\n");
            Console.WriteLine("Enter Food plan name:   ");
            food_plan_to_add.Name = Validations.check_if_input_include_special_char(',');

            if (Food_plan_DL.is_plan_name_unique(food_plan_to_add.Name))
            {
                Console.WriteLine("\nBreakfast: ");
                food_plan_to_add.Break_fast = Food_item_UI.get_new_item_input();
                Console.WriteLine("\nLunch: ");
                food_plan_to_add.Break_fast = Food_item_UI.get_new_item_input();
                Console.WriteLine("\nDinner: ");
                food_plan_to_add.Break_fast = Food_item_UI.get_new_item_input();
            }
            else
            {
                return;
            }

            Food_plan_DL.add_food_plan_to_list(food_plan_to_add);
            Console.WriteLine("Plan successfully added.");
        }





        // Show available food plans
        public static void show_available_food_plans()
        {
            Console.WriteLine($"Plan name                   Breakfast                             Lunch                        Dinner                     Total price\n");
            foreach (Food_plan plan_of_iteration in Food_plan_DL.food_plans_available)
            {
                Console.WriteLine($"{plan_of_iteration.Name}                   {plan_of_iteration.Break_fast.Name}                             {plan_of_iteration.Lunch.Name}                        {plan_of_iteration.Dinner.Name}                      {plan_of_iteration.get_total_price()}");
            }
        }




        // Edit food plan
        public static void edit_food_plan()
        {
            Program_UI.clear_screen();
            string plan_name;
            Console.WriteLine("    Edit food plan\n");
            show_available_food_plans();
            Console.Write("Enter plan name to edit details:  ");
            plan_name = Validations.check_if_input_include_special_char(',');

            if(Food_plan_DL.get_food_plan_from_name(plan_name) != null)
            {
                string option;
                Console.WriteLine("Which of the meal do you want to edit?");
                Console.WriteLine("1. Breakfast");
                Console.WriteLine("2. Lunch");
                Console.WriteLine("3. Dinner");
                Console.Write("Select option");
                option = Validations.check_if_input_include_special_char(',');

                if(option == "1")
                {
                    Console.WriteLine("Enter new Breakfast details");
                    Food_plan_DL.get_food_plan_from_name(plan_name).Break_fast = Food_item_UI.get_new_item_input();
                    Console.WriteLine("Updated successfully.");
                    Program_UI.pause();
                }

                else if (option == "2")
                {
                    Console.WriteLine("Enter new Lunch details");
                    Food_plan_DL.get_food_plan_from_name(plan_name).Lunch = Food_item_UI.get_new_item_input();
                    Console.WriteLine("Updated successfully.");
                    Program_UI.pause();
                }

                else if(option == "3")
                {
                    Console.WriteLine("Enter new Breakfast details");
                    Food_plan_DL.get_food_plan_from_name(plan_name).Dinner = Food_item_UI.get_new_item_input();
                    Console.WriteLine("Updated successfully.");
                    Program_UI.pause();
                }

                else
                {
                    Console.WriteLine("Please select a valid option.");
                    Program_UI.pause();
                    edit_food_plan();
                    return;
                }
            }

            else
            {
                Console.WriteLine("Please enter a valid plane name.");
                Program_UI.pause();
            }
        }





    }
}
