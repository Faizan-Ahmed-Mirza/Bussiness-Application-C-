﻿using Bussiness_Application.BL;
using Bussiness_Application.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.UI
{
    public class Room_UI
    {
        public static void add_new_room()
        {
            Program_UI.clear_screen();
            Room room_to_add = new Room();
            Console.WriteLine("     Add Room");
            Console.Write("Enter Room no: ");
            room_to_add.Room_no = Validations.check_if_input_include_special_char(',');

            // If room no unique , take other entries
            if (Room_DL.is_room_no_unique(room_to_add.Room_no))
            {
                string ac_availability, tv_availability;
                Console.Write("Enter rent per head:   ");
                room_to_add.Rent_per_head = Validations.get_double_input();
                Console.Write("Enter room space:   ");
                room_to_add.Client_space = (int)Validations.get_double_input();
                // Ac
                Console.Write("Is Ac available(yes/no):  ");
                ac_availability = Validations.check_if_input_include_special_char(',').ToLower();
                if (ac_availability == "yes")
                {
                    room_to_add.Is_ac_available = true;
                }
                else if (ac_availability == "no")
                {
                    room_to_add.Is_ac_available = false;
                }
                else
                {
                    Console.WriteLine("Please enter valid input.");
                    Program_UI.pause();
                    add_new_room();
                    return;
                }
                // TV
                Console.Write("Is Tv available(yes/no):  ");
                tv_availability = Validations.check_if_input_include_special_char(',').ToLower();
                if (tv_availability == "yes")
                {
                    room_to_add.Is_tv_available = true;
                }
                else if (tv_availability == "no")
                {
                    room_to_add.Is_tv_available = false;
                }
                else
                {
                    Console.WriteLine("Please enter valid input.");
                    Program_UI.pause();
                    add_new_room();
                    return;
                }

                // Adding to list
                Room_DL.add_room_to_list(room_to_add);
                Console.WriteLine("\nRoom added successfully.");
                Program_UI.pause();
            }
        }



        // Show Rooms list
        public static void show_clients_in_room(Room room_to_show_clients)
        {
            User sample_user;
            Console.WriteLine("Name              Cnic                  Phone no             Rent               Date of joining");
            foreach (string string_of_iteration in room_to_show_clients.clients_in_room)
            {
                sample_user = Person_DL.get_registered_user_from_username(string_of_iteration);
                Console.WriteLine($"{sample_user.Username}              {sample_user.Cnic}                  {sample_user.Phone_no}             {sample_user.Rent_charged}               {sample_user.Date_of_joining}");
            }
            Program_UI.pause();
        }



        // Show a specific room details
        public static void specific_room_details(Room room_to_show_details)
        {
            Console.WriteLine($"Room no:  {room_to_show_details}");
            Console.WriteLine($"Rent per head:  {room_to_show_details.Rent_per_head}");
            // Ac
            if (room_to_show_details.Is_ac_available)
            {
                Console.WriteLine("Ac:   available");
            }
            else
            {
                Console.WriteLine("Ac:   not available");
            }
            // TV
            if (room_to_show_details.Is_tv_available)
            {
                Console.WriteLine("Television:   available");
            }
            else
            {
                Console.WriteLine("Television:    not available");
            }
            // Room space
            Console.WriteLine($"Client space:     {room_to_show_details.Client_space}");
            Console.WriteLine($"Clients already registered:   {room_to_show_details.clients_in_room.Count}");
        }



        // View available rooms
        public static void show_available_rooms()
        {
            Program_UI.clear_screen();
            string ac_availability = "Not available";
            string tv_availability = "Not available";
            string room_availability_sting = "Not availabe";
            Console.WriteLine("Room no              Status              Space left              Clients registered             Ac                Television              Rent");

            foreach (Room room_of_iteration in Room_DL.rooms_list)
            {
                if (room_of_iteration.Is_free_or_occupied)
                {
                    room_availability_sting = "Free";
                }
                if (room_of_iteration.Is_tv_available)
                {
                    tv_availability = "Available";
                }
                if (room_of_iteration.Is_ac_available)
                {
                    ac_availability = "Available";
                }
                Console.WriteLine($"{room_of_iteration.Room_no}             {room_availability_sting}              {room_of_iteration.get_space_left()}             {room_of_iteration.clients_in_room.Count}             {ac_availability}                {tv_availability}              {room_of_iteration.Rent_per_head}");
                // Reset 
                ac_availability = "Not available";
                tv_availability = "Not available";
                room_availability_sting = "Not availabe";
            }
            Program_UI.pause();
        }




        // Edit details of a room
        public static void edit_room_details()
        {
            Program_UI.clear_screen();
            string changed_entity;
            string room_no;
            Console.WriteLine("                    Edit room details.");
            show_available_rooms();
            Console.WriteLine("Enter room no to edit details for:  ");
            room_no = Validations.check_if_input_include_special_char(',');

            if (Room_DL.get_room_from_room_no(room_no) != null)
            {
                string option, internal_option;
                Console.WriteLine("Enter 0 to return.");
                Console.WriteLine("Which entity to change?");
                Console.WriteLine(" 1. Room no");
                Console.WriteLine(" 2. Client Space");
                Console.WriteLine(" 3. Ac availability");
                Console.WriteLine(" 4. Tv availability");
                Console.WriteLine(" 5. Rent per head\n");
                Console.Write("Enter option:  ");
                option = Validations.check_if_input_include_special_char(',');

                if (option == "0")
                {
                    return;
                }
                // Room no
                else if (option == "1")
                {
                    Console.Write("Enter new Room no:  ");
                    changed_entity = Validations.check_if_input_include_special_char(',');
                    if (Room_DL.is_room_no_unique(changed_entity))
                    {
                        Room_DL.get_room_from_room_no(room_no).Room_no = changed_entity;
                        Console.WriteLine("Room no updated successfully.");
                        Program_UI.pause();
                    }
                    else
                    {
                        Console.WriteLine("Room with same name already exists.");
                        Program_UI.pause();
                        edit_room_details();
                        return;
                    }
                }
                // Room Space
                else if (option == "2")
                {
                    Console.Write("Enter new room space:  ");
                    changed_entity = Convert.ToString(Validations.get_double_input());
                    Room_DL.get_room_from_room_no(room_no).Client_space = int.Parse(changed_entity);
                }
                // Ac
                else if (option == "3")
                {
                    Console.WriteLine("Is ac avaialble?\n");
                    Console.WriteLine("0. No");
                    Console.WriteLine("1. Yes");
                    internal_option = Validations.check_if_input_include_special_char(',');

                    if (internal_option == "0")
                    {
                        Room_DL.get_room_from_room_no(room_no).Is_ac_available = false;
                        Console.WriteLine("Updated successfully.");
                    }
                    else if (internal_option == "1")
                    {
                        Room_DL.get_room_from_room_no(room_no).Is_ac_available = true;
                        Console.WriteLine("Updated successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Please enter a valid option");
                    }
                    Program_UI.pause();
                }
                // Tv
                else if (option == "4")
                {
                    Console.WriteLine("Is Tv avaialble?\n");
                    Console.WriteLine("0. No");
                    Console.WriteLine("1. Yes");
                    internal_option = Validations.check_if_input_include_special_char(',');

                    if (internal_option == "0")
                    {
                        Room_DL.get_room_from_room_no(room_no).Is_tv_available = false;
                        Console.WriteLine("Updated successfully.");
                    }
                    else if (internal_option == "1")
                    {
                        Room_DL.get_room_from_room_no(room_no).Is_tv_available = true;
                        Console.WriteLine("Updated successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Please enter a valid option");
                    }
                    Program_UI.pause();
                }
                // Rent per head
                else if (option == "5")
                {
                    Console.Write("Enter new Rent per head:  ");
                    changed_entity = Convert.ToString(Validations.get_double_input());

                    Room_DL.get_room_from_room_no(room_no).Rent_per_head = double.Parse(changed_entity);
                    Console.WriteLine("Rent updated successfully.");
                    Program_UI.pause();
                }
            }
        }




    }
}
