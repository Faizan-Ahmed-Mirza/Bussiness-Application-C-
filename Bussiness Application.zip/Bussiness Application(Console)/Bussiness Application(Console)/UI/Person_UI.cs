﻿using Bussiness_Application.BL;
using Bussiness_Application.DL;
using Bussiness_Application_Console_.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.UI
{
    public class Person_UI
    {
        // Change password
        public static void change_password(Person person_to_change_password)
        {
            Program_UI.clear_screen();
            string current_password;
            string new_password;
            Console.Write("Enter your current password for conformation:  ");
            current_password = Validations.check_if_input_include_special_char(',');
            if (current_password == person_to_change_password.Password)
            {
                Console.Write("Enter new password:  ");
                new_password = Validations.check_if_input_include_special_char(',');
                Console.Write("Confirm password:  ");
                if(new_password == Validations.check_if_input_include_special_char(','))
                {
                    person_to_change_password.Password = new_password;
                    Console.WriteLine("Password successfully changed.");
                }
                else
                {
                    Console.WriteLine("Match doesn't match.");
                }
            }
            else
            {
                Console.WriteLine("Invalid password.");
            }

            Program_UI.pause();
        }


        // Delete account
        public static void delete_account(Person person_to_delete)
        {
            Program_UI.clear_screen();
            string option;

            Console.WriteLine("Are you sure you want to delete your account?");
            Console.WriteLine("  0. No(return)");
            Console.WriteLine("  1. Yes \n\n");
            Console.Write("Enter option:  ");
            option = Validations.check_if_input_include_special_char(',');

            // Conditional 
            if (option == "0")
            {
                return;
            }
            else if (option == "1")
            {
                Person_DL.remove_un_verified_person(person_to_delete);
                Console.WriteLine("Account deleted successfully.");
            }

            Program_UI.pause();
        }


        // View un-verified Persons
        public static void show_un_verified_user()
        {
            Console.WriteLine("Role             Username             Cnic             Room no             Phone no               Rent                Food Charges             Date of joining");
            foreach (Person person_of_iteration in Person_DL.un_verified_persons)
            {
                if(person_of_iteration is User)
                {
                    User Person_of_iteration = new User();
                    Person_of_iteration = (User)person_of_iteration;
                    Console.WriteLine($"Client             {Person_of_iteration.Username}             {Person_of_iteration.Cnic}             {Person_of_iteration.Room_registered.Room_no}             {Person_of_iteration.Phone_no}               {Person_of_iteration.Room_registered.Rent_per_head}                {Person_of_iteration.Subscribed_food_plan.get_total_price()}             {Person_of_iteration.Date_of_joining}");
                }
                else if(person_of_iteration is Owner)
                {
                    Console.WriteLine($"Admin             {person_of_iteration.Username}             {person_of_iteration.Cnic}              --             {person_of_iteration.Phone_no}                --                  --               {person_of_iteration.Date_of_joining}");
                }
            }
        }




        // View registered persons
        public static void show_registered_persons()
        {
            Console.WriteLine("Username             Cnic             Room no             Phone no               Rent                Food Charges             Date of joining");
            foreach (Person person_of_iteration in Person_DL.registered_person)
            {
                if (person_of_iteration is User)
                {
                    User Person_of_iteration = new User();
                    Person_of_iteration = (User)person_of_iteration;
                    Console.WriteLine($"{Person_of_iteration.Username}             {Person_of_iteration.Cnic}             {Person_of_iteration.Room_registered.Room_no}             {Person_of_iteration.Phone_no}               {Person_of_iteration.Room_registered.Rent_per_head}                {Person_of_iteration.Subscribed_food_plan.get_total_price()}             {Person_of_iteration.Date_of_joining}");
                }
                else if (person_of_iteration is Owner)
                {
                    Console.WriteLine($"{person_of_iteration.Username}             {person_of_iteration.Cnic}              --             {person_of_iteration.Phone_no}                --                  --               {person_of_iteration.Date_of_joining}");
                }
            }
        }





        // set common bill for eveyone
        public static void set_common_bill()
        {
            Program_UI.clear_screen();
            double elctric, water, gas;
            Console.Write("Enter electricity bill:  ");
            elctric = double.Parse(Validations.check_if_input_include_special_char(','));
            Console.Write("Enter Water bill:  ");
            water = double.Parse(Validations.check_if_input_include_special_char(','));
            Console.Write("Enter Gas bill:  ");
            gas = double.Parse(Validations.check_if_input_include_special_char(','));

            Person_DL.set_common_bill(elctric, water, gas);
            Console.WriteLine("Updated successfully");
            Program_UI.pause();

        }




    }
}
