﻿using Bussiness_Application.BL;
using Bussiness_Application.DL;
using Bussiness_Application_Console_.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.UI
{
    class Program_UI
    {
        // Main menu
        public static string mainmenu()
        {
            clear_screen();
            string option;
            Console.WriteLine("  Main Menu\n\n");
            Console.WriteLine("1. Sign up");
            Console.WriteLine("2. Sign in");
            Console.WriteLine("3. Exit\n\n");

            Console.Write("Enter option: ");
            option = Validations.check_if_input_include_special_char(',');

            return option;
        }



        // Sign in
        public static Person Sign_in()
        {
            clear_screen();
            // Taking Credentials
            string username, password;
            Console.WriteLine(" Sign in \n");
            Console.Write("Enter username: ");
            username = Validations.check_if_input_include_special_char(',');
            Console.Write("Enter password: ");
            password = Validations.check_if_input_include_special_char(',');

            // Returning person
            // If user is valid
            if (Person_DL.get_registered_person(username, password) != null)
            {
                Console.WriteLine("Login successfull.");
                pause();
                return Person_DL.get_registered_person(username, password);
            }

            else
            {
                // User is under verificaton
                if (Person_DL.get_un_verified_person(username, password) != null)
                {
                    Console.WriteLine("Your account is not approved by admins yet. Have patience please.");
                    pause();
                    return null;
                }

                // Wrong Credentials
                else
                {
                    Console.WriteLine("Wrong Credentials");
                    pause();
                    return null;
                }
            }
        }




        // header
        public static void header()
        {
            Console.WriteLine("\n\n\n");
            Console.WriteLine("                                                                                                                                          ");
            Console.WriteLine("               ,------.        ,--.                        ,--.          ,--.  ,--.               ,--.         ,--.                       ");
            Console.WriteLine("              |  .--. ' ,---. |  ,---. ,--,--,--. ,--,--.,-'  '-.        |  '--'  | ,---.  ,---.,-'  '-. ,---. |  |                       ");
            Console.WriteLine("              |  '--'.'| .-. :|  .-.  ||        |' ,-.  |'-.  .-'        |  .--.  || .-. |(  .-''-.  .-'| .-. :|  |                       ");
            Console.WriteLine("              |  |\\  \\ \\   --.|  | |  ||  |  |  |\\ '-'  |  |  |          |  |  |  |' '-' '.-'  `) |  |  \\   --.|  |                  ");
            Console.WriteLine("              `--' '--' `----'`--' `--'`--`--`--' `--`--'  `--'          `--'  `--' `---' `----'  `--'   `----'`--'                       ");
            Console.WriteLine("                                                                                                                                          \n\n\n");
        }



        // Sign up
        public static void Sign_up()
        {
            clear_screen();
            Person person_to_sign_up = new Person();
            string username, password, role;

            // Taking username
            Console.WriteLine(" Sign up/Add User \n");
            Console.Write("Enter username: ");
            username = Validations.check_if_input_include_special_char(',');

            if (Person_DL.Is_username_unique(username))
            {
                // Taking password and role
                Console.WriteLine("Enter password:  ");
                password = Validations.check_if_input_include_special_char(',');
                Console.Write("Enter Role (owner/client):  ");
                role = Validations.check_if_input_include_special_char(',').ToLower();

                // For client
                if (role == "client")
                {
                    person_to_sign_up = User_UI.take_client_input(username, password);

                }
                // For owner
                else if (role == "owner")
                {
                    Owner owner_to_verify = new Owner(username, password);
                    person_to_sign_up = owner_to_verify;
                }
                // Invalid role input
                else
                {
                    Console.WriteLine("Enter a valid role to sign up");
                    pause();
                    return;
                }

                // Adding to unverified list

                Person_DL.un_verified_persons.Add(person_to_sign_up);
                Console.WriteLine("Your application has been successfully sent to admins for review , your account shall be active as soon admins approve it.");
                pause();
            }
            // User already registered
            else
            {
                Console.WriteLine("User is already registered.");
                pause();
            }
        }


        // Load
        public static void load_data()
        {
            Food_plan_DL.load_plans();
            Room_DL.load_rooms();
            Person_DL.load_registered_persons();
            Person_DL.load_un_verified_persons();
        }



        // Store
        public static void store_data()
        {
            Food_plan_DL.store_plans();
            Room_DL.store_rooms();
            Person_DL.store_registered_persons();
            Person_DL.store_un_verified_persons();
        }


        // Pause function
        public static void pause()
        {
            Console.Write("Press any key to continue....");
            Console.ReadKey();
        }



        // Clear screen
        public static void clear_screen()
        {
            Console.Clear();
            header();
        }
    }
}
