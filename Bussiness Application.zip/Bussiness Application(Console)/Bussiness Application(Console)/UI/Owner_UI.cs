﻿using Bussiness_Application.BL;
using Bussiness_Application.DL;
using Bussiness_Application_Console_.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.UI
{
    public class Owner_UI
    {
        // Owner Menu
        public static string admin_menu(Owner owner_logged_in)
        {
            Program_UI.clear_screen();
            string option;
            Console.WriteLine("       Admin Panal");
            Console.WriteLine($" Welcome {owner_logged_in.Username}\n");
            Console.WriteLine(" 0. Return.");
            Console.WriteLine(" 1. See available rooms details.");
            Console.WriteLine(" 2. Add new client.");
            Console.WriteLine(" 3. Add a new room.");
            Console.WriteLine(" 4. Add a new Food plan.");
            Console.WriteLine(" 5. Impose fine to a client.");
            Console.WriteLine(" 6. Mark discount to a client.");
            Console.WriteLine(" 7. Edit details of a client.");
            Console.WriteLine(" 8. Edit details of a room.");
            Console.WriteLine(" 9. Edit a Food Plan.");
            Console.WriteLine("10. See total payable of a client.");
            Console.WriteLine("11. View pending approvals.");
            Console.WriteLine("12. View complains");
            Console.WriteLine("13. Set common bill amount for everyone.");
            Console.WriteLine("14. Clear/Add pending payable of a client.");
            Console.WriteLine("15. View total income.");
            Console.WriteLine("16. Remove a client");
            Console.WriteLine("17. Exit\\Logout \n\n");
            Console.Write("Enter option: ");
            option = Validations.check_if_input_include_special_char(',');

            return option;
        }



        // Add new client
        public static void add_new_client()
        {
            string option;
            Program_UI.Sign_up();

        After_Sign_up:
            Console.WriteLine("Do you want the user(you recently added) to be approved?");
            Console.WriteLine("1. Yes");
            Console.WriteLine("0. No\n");
            Console.Write("Enter option:  ");
            option = Validations.check_if_input_include_special_char(',');
            if (option == "1")
            {
                Person_DL.promote_to_registered(Person_DL.un_verified_persons[Person_DL.un_verified_persons.Count - 1]);
                Console.WriteLine("USer approved successfully.");
            }
            else if (option == "0")
            {
                return;
            }
            else
            {
                Console.WriteLine("Please enter a valid option.");
                Program_UI.pause();
                goto After_Sign_up;
            }
        }



        // Mark discount
        public static void mark_discount()
        {
            Program_UI.clear_screen();
            string username;
            double discount;
            User_UI.show_registered_user();

        Take_username_again:
            Console.WriteLine("Enter 0 to return.");
            Console.WriteLine("Enter username to mark discount: ");
            username = Validations.check_if_input_include_special_char(',');
            if (Person_DL.get_registered_user_from_username(username) != null)
            {
                Console.Write("Enter amount to mark discount");
                discount = double.Parse(Validations.check_if_input_include_special_char(','));
                Person_DL.get_registered_user_from_username(username).Net_surplus = Person_DL.get_registered_user_from_username(username).Net_surplus + discount;
                Console.WriteLine("Discount successfully marked.");
            }
            else if (username == "0")
            {
                return;
            }
            else
            {
                Console.WriteLine("Please enter a valid username.");
                goto Take_username_again;
            }
            Program_UI.pause();
        }



        // impose fine
        public static void impose_fine()
        {
            Program_UI.clear_screen();
            string username;
            double fine;
            User_UI.show_registered_user();

        Take_username_again:
            Console.WriteLine("Enter 0 to return.");
            Console.WriteLine("Enter username to impose fine: ");
            username = Validations.check_if_input_include_special_char(',');
            if (Person_DL.get_registered_user_from_username(username) != null)
            {
                Console.Write("Enter amount to impose fine");
                fine = double.Parse(Validations.check_if_input_include_special_char(','));
                Person_DL.get_registered_user_from_username(username).Net_surplus = Person_DL.get_registered_user_from_username(username).Net_surplus - fine;
                Console.WriteLine("Discount successfully marked.");
            }
            else if (username == "0")
            {
                return;
            }
            else
            {
                Console.WriteLine("Please enter a valid username.");
                goto Take_username_again;
            }
            Program_UI.pause();
        }




        // edit details of a client
        public static void edit_client_details()
        {
            Program_UI.clear_screen();
            string username;
            User_UI.show_registered_user();
        Take_username_again:
            Console.WriteLine("\nEnter 0 to return.");
            Console.Write("Enter username to edit details for:  ");
            username = Validations.check_if_input_include_special_char(',');
            if (username == "0")
            {
                return;
            }
            if (Person_DL.get_registered_user_from_username(username) != null)
            {
                User sample_user;
                sample_user = Person_DL.get_registered_user_from_username(username);
                string option;
                string new_entity;
                Console.WriteLine("Select detail to edit.");
                Console.WriteLine(" 1. Username.");
                Console.WriteLine(" 2. Password.");
                Console.WriteLine(" 3. Rent.");
                Console.WriteLine(" 4. Cnic.");
                Console.WriteLine(" 5. Phone no.");
                Console.WriteLine(" 6. Room no.");
                Console.WriteLine(" 7. Food Plan.");
                Console.WriteLine(" 8. Pending amount.");
                Console.WriteLine(" 9. Bills.");
                Console.WriteLine("10. Surplus amount(discount/fine).\n\n");
                option = Validations.check_if_input_include_special_char(',');
                // Username
                if (option == "1")
                {
                    Program_UI.clear_screen();
                    Console.WriteLine("Press 0 to return");
                    Console.Write("Enter new username:   ");
                    new_entity = Validations.check_if_input_include_special_char(',');
                    if (new_entity != "0")
                    {
                        sample_user.Username = new_entity;
                        Console.WriteLine("Username successfully updated.");
                        Program_UI.pause();
                    }
                }
                // Password
                else if (option == "2")
                {
                    Program_UI.clear_screen();
                    Console.WriteLine("Enter 0 to return.");
                    Console.Write("Enter new password:  ");
                    new_entity = Validations.check_if_input_include_special_char(',');
                    if (new_entity != "0")
                    {
                        sample_user.Password = new_entity;
                        Console.WriteLine("Password successfully updated.");
                        Program_UI.pause();
                    }
                }
                // Rent
                else if (option == "3")
                {
                    Program_UI.clear_screen();
                    Console.WriteLine("Enter 0 to return.");
                    Console.Write("Enter new rent:  ");
                    new_entity = Convert.ToString(Validations.get_double_input());
                    if (new_entity != "0")
                    {
                        sample_user.Rent_charged = double.Parse(new_entity);
                        Console.WriteLine("Rent updated successfully.");
                        Program_UI.pause();
                    }
                }
                // Cnic
                else if (option == "4")
                {
                    Program_UI.clear_screen();
                    Console.WriteLine("Enter 0 to return.");
                    Console.Write("Enter new cnic no:   ");
                    new_entity = Convert.ToString(Validations.get_double_input());
                    if (new_entity != "0")
                    {
                        sample_user.Cnic = new_entity;
                        Console.WriteLine("Cnic updated successfully.");
                        Program_UI.pause();
                    }
                }
                // Phone no
                else if (option == "5")
                {
                    Program_UI.clear_screen();
                    Console.WriteLine("Enter 0 to return.");
                    Console.Write("Enter new phone no:   ");
                    new_entity = Convert.ToString(Validations.get_double_input());
                    if (new_entity != "0")
                    {
                        sample_user.Phone_no = new_entity;
                        Console.WriteLine("Phone number updated successfully.");
                        Program_UI.pause();
                    }
                }
                // Room no
                else if (option == "6")
                {
                    Program_UI.clear_screen();
                    Room_UI.show_available_rooms();
                    Console.WriteLine("\n\nEnter 0 to return.");
                    Console.Write("Enter new room no:   ");
                    new_entity = Validations.check_if_input_include_special_char(',');
                    if (new_entity != "0")
                    {
                        if (Room_DL.get_room_from_room_no(new_entity) != null)
                        {
                            sample_user.Room_registered = Room_DL.get_room_from_room_no(new_entity);
                            Console.WriteLine("Room no updated successfully.");
                        }
                        else
                        {
                            Console.WriteLine("Please enter a valid room no.");
                        }
                        Program_UI.pause();
                    }
                }
                // Food plan
                else if (option == "7")
                {
                    Program_UI.clear_screen();
                    Food_plan_UI.show_food_plans();
                    Console.WriteLine("\n\nEnter 0 to return.");
                    Console.Write("Enter new food plane name:   ");
                    new_entity = Validations.check_if_input_include_special_char(',');
                    if (new_entity != "0")
                    {
                        if (Food_plan_DL.get_food_plan_from_name(new_entity) != null)
                        {
                            sample_user.Subscribed_food_plan = Food_plan_DL.get_food_plan_from_name(new_entity);
                            Console.WriteLine("Food plan updated successfully.");
                        }
                        else
                        {
                            Console.WriteLine("Please enter a valid food plan name.");
                        }
                        Program_UI.pause();
                    }
                }
                // Pending amount
                else if (option == "8")
                {
                    Program_UI.clear_screen();
                    Console.WriteLine("Enter 0 to return.");
                    Console.Write("Enter updated pending amount for client:   ");
                    new_entity = Convert.ToString(Validations.get_double_input());
                    if (new_entity != "0")
                    {
                        sample_user.Pending_payment = double.Parse(new_entity);
                        Console.WriteLine("Pending payable updated successfully.");
                        Program_UI.pause();
                    }
                }
                // Bills
                else if (option == "9")
                {
                    edit_client_bills(sample_user);
                }
                // Surplus
                else if (option == "10")
                {
                    Program_UI.clear_screen();
                    Console.WriteLine("Enter 0 to return.");
                    Console.Write("Enter new surplus amount for client (+ve for fine / -ve for discount):   ");
                    new_entity = Convert.ToString(Validations.get_double_input());
                    if (new_entity != "0")
                    {
                        sample_user.Net_surplus = double.Parse(new_entity);
                        Console.WriteLine("Surplus amount updated successfully.");
                        Program_UI.pause();
                    }
                }
            }

            // Invalid username
            else
            {
                Console.WriteLine("Please enter a valid username.");
                goto Take_username_again;
            }
            Program_UI.pause();
        }






        // Edit client bills
        private static void edit_client_bills(User sample_user)
        {
            string option;
            string changed_entity;
            Program_UI.clear_screen();
            Console.WriteLine("           Edit client details\n\n");
            Console.WriteLine("Enter 0 to retrun.\n");
            Console.WriteLine("1. Electric bill");
            Console.WriteLine("2. Water bill");
            Console.WriteLine("3. Gas bill\n\n");
            Console.Write("Enter option:  ");
            option = Validations.check_if_input_include_special_char(',');
            // Return
            if (option == "0")
            {
                return;
            }
            // Electric bill
            if (option == "1")
            {
                Console.WriteLine("Enter 0 to return");
                Console.WriteLine($"Client current monthly electric bill is {sample_user.Electric_bill}");
                Console.Write("Enter new Electric bill:");
                changed_entity = Convert.ToString(Validations.get_double_input());

                if (changed_entity != "0")
                {
                    sample_user.Electric_bill = double.Parse(changed_entity);
                    Console.WriteLine("Electric bill updated successfully.");
                    Program_UI.pause();
                }
            }
            // Water bill
            else if (option == "2")
            {
                Console.WriteLine("Enter 0 to return");
                Console.WriteLine($"Client current monthly water is {sample_user.Water_bill}");
                Console.Write("Enter new Water bill:");
                changed_entity = Convert.ToString(Validations.get_double_input());
                if (changed_entity != "0")
                {
                    sample_user.Water_bill = double.Parse(changed_entity);
                    Console.WriteLine("Water bill updated successfully.");
                    Program_UI.pause();
                }
            }
            // Gas bill
            else if (option == "3")
            {
                Console.WriteLine("Enter 0 to return");
                Console.WriteLine($"Client current monthly gas bill is {sample_user.Gas_bill}");
                Console.Write("Enter new Gas bill:");
                changed_entity = Convert.ToString(Validations.get_double_input());
                if (changed_entity != "0")
                {
                    sample_user.Gas_bill = double.Parse(changed_entity);
                    Console.WriteLine("Gas bill updated successfully.");
                    Program_UI.pause();
                }
            }
            // Invlaid option
            else
            {
                Console.WriteLine("Please enter a valid option.");
                edit_client_bills(sample_user);
            }
        }




        // clear payable of a client
        public static void clear_add_pending_of_client()
        {
            Program_UI.clear_screen();
            string username;
            Console.WriteLine("           Clear/Add Pending amounts");
            User_UI.show_registered_user();
            Console.Write("\n Enter username to clear bill:  ");
            username = Validations.check_if_input_include_special_char(',');
            User sample_client = Person_DL.get_registered_user_from_username(username);

            if (Person_DL.get_registered_user_from_username(username) != null)
            {
                string option;
                Console.WriteLine($"Client has a total of Rs.{sample_client.Pending_payment} pending payment and Rs.{sample_client.get_current_month_payable()} of current payable\n\n");
                Console.WriteLine("");
                Console.WriteLine("0. Return");
                Console.WriteLine("1. Clear Pending amount.");
                Console.WriteLine("2. Add pending amount against client.");
                option = Validations.check_if_input_include_special_char(',');

                if (option == "0")
                {
                    return;
                }

                else if (option == "1")
                {
                    sample_client.Pending_payment = 0;
                    Console.WriteLine("Cleared successfully");
                }

                else if (option == "2")
                {
                    Console.WriteLine("Enter amount to add in pending bill.");
                    sample_client.Pending_payment = Validations.get_double_input();
                    Console.WriteLine("Updated successfully");
                }
                else
                {
                    Console.WriteLine("Please select valid option.");
                    Program_UI.pause();
                    clear_add_pending_of_client();
                    return;
                }
            }

            else
            {
                Console.WriteLine("Please enter a valid username.");
                Program_UI.pause();
                clear_add_pending_of_client();
                return;
            }
        }





        // See total payable of a client
        public static void see_total_payable_of_a_client()
        {
            Program_UI.clear_screen();
            string username;
            User user_to_display;
            Console.WriteLine("Enter 0 to return.");
            User_UI.show_registered_user();
            Console.Write("\n\nEnter username to see a client's total payable:   ");
            username = Validations.check_if_input_include_special_char(',');

            user_to_display = Person_DL.get_registered_user_from_username(username);
            Console.WriteLine($"Client Pending payment:    {user_to_display.Pending_payment}");
            Console.WriteLine($"Client Surplus:    {user_to_display.Net_surplus}");
            Console.WriteLine($"Client payable this month:    {user_to_display.get_current_month_payable()}\n");
            Console.WriteLine($"Client total payable:      {user_to_display.get_total_payable()}");
            Program_UI.pause();
        }






        //View pending approvals
        public static void view_pending_approvals_panal()
        {
            Program_UI.clear_screen();
            string option;
            string username;
            Console.WriteLine("        Pending approvals         \n\n");
            Person_UI.show_un_verified_user();

            Console.WriteLine("\n\n0. Return");
            Console.WriteLine("1. Approve an application.");
            Console.WriteLine("2. Reject application.");
            Console.Write("\n Enter option:   ");
            option = Validations.check_if_input_include_special_char(',');
            //Return
            if (option == "0")
            {
                return;
            }
            // Approve request
            else if (option == "1")
            {
                Console.WriteLine("Enter username to approve request:   ");
                username = Validations.check_if_input_include_special_char(',');
                if (Person_DL.get_un_verified_user_from_username(username) != null)
                {
                    Person_DL.promote_to_registered(Person_DL.get_un_verified_user_from_username(username));
                    Console.WriteLine("Request successfully approved.");
                    Program_UI.pause();
                }
                else
                {
                    Console.WriteLine("Please enter a valid username.");
                    Program_UI.pause();
                    view_pending_approvals_panal();
                    return;
                }
            }
            // Reject request
            else if (option == "2")
            {
                Console.WriteLine("Enter username to reject request:   ");
                username = Validations.check_if_input_include_special_char(',');
                if (Person_DL.get_un_verified_user_from_username(username) != null)
                {
                    Person_DL.remove_un_verified_person(Person_DL.get_un_verified_user_from_username(username));
                    Console.WriteLine("Request rejected successfully.");
                    Program_UI.pause();
                }
                else
                {
                    Console.WriteLine("Please enter a valid username.");
                    Program_UI.pause();
                    view_pending_approvals_panal();
                    return;
                }
            }
            // Invalid option
            else
            {
                Console.WriteLine("Please enter a valid option.");
                Program_UI.pause();
                view_pending_approvals_panal();
            }
        }






        // View complains
        public static void view_complain()
        {
            Program_UI.clear_screen();
            Console.WriteLine("          Client Complains");
            foreach (User client_of_iteration in Person_DL.registered_person)
            {
                Console.WriteLine($"\n{client_of_iteration.Username}:  ");
                Console.WriteLine($"          {client_of_iteration.Complain}");
            }
            Program_UI.pause();
        }




        // Calculate total income
        public static void view_total_income()
        {
            Program_UI.clear_screen();
            double total_income = 0;
            foreach (User client_of_iteration in Person_DL.registered_person)
            {
                total_income = total_income + client_of_iteration.get_total_payable();
            }

            Console.WriteLine("        Total income this month");
            Console.WriteLine($"\n\nThere are a total of {Person_DL.registered_person.Count} clients.");
            Console.WriteLine($"Your total income this month is:     {total_income}");
            Program_UI.pause();
        }



        // Remove a client
        public static void remove_a_client()
        {
            Program_UI.clear_screen();
            string username;
            User_UI.show_registered_user();
            Console.Write("\n\nEnter username to remove:  ");
            username = Validations.check_if_input_include_special_char(',');

            if (Person_DL.get_registered_user_from_username(username) != null)
            {
                Person_DL.remove_verified_person(Person_DL.get_registered_user_from_username(username));
                Console.WriteLine("Client removed successfully.");
            }

            else
            {
                Console.WriteLine("Please enter a valid username.");
            }
            Program_UI.pause();

        }






    }
}




