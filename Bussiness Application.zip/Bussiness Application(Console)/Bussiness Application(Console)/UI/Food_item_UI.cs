﻿using Bussiness_Application.BL;
using Bussiness_Application_Console_.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.UI
{
    public class Food_item_UI
    {
        public static Food_item get_new_item_input()
        {
            Food_item item_to_add = new Food_item();
            Console.WriteLine("Enter Item name:   ");
            item_to_add.Name = Validations.check_if_input_include_special_char(',');
            Console.Write("Enter Item Price: ");
            item_to_add.Price = (int)Validations.get_double_input();

            return item_to_add;
        }
    }
}
