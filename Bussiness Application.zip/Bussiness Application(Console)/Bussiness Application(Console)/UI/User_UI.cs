﻿using Bussiness_Application.BL;
using Bussiness_Application.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.UI
{
    public class User_UI
    {
        // User Menu
        public static string User_menu(User user_logged_in)
        {
            Program_UI.clear_screen();
            string option;
            Console.WriteLine($"Welcome {user_logged_in.Username}\n\n");
            Console.WriteLine("  User Panal");
            Console.WriteLine(" 0. Go back.           ");
            Console.WriteLine(" 1. See available rooms.                       ");
            Console.WriteLine(" 2. Select food plan.                          ");
            Console.WriteLine(" 3. Un-subscribe your food plan.               ");
            Console.WriteLine(" 4. See your total payable.                    ");
            Console.WriteLine(" 5. Submit a complaint.                        ");
            Console.WriteLine(" 6. Change password.                           ");
            Console.WriteLine(" 7. View your information.                     ");
            Console.WriteLine(" 8. View your room details.                    ");
            Console.WriteLine(" 9. Delete account.                            ");
            Console.WriteLine("10. Exit.                                  \n\n");

            Console.Write("Enter option: ");
            option = Validations.check_if_input_include_special_char(',');

            return option;
        }




        // Taking input for client
        public static User take_client_input(string username, string password)
        {
            User user_to_return = new User(username, password);
            string date_of_joining, room_no, cnic, phone_no;

            // Taking input
            Console.Write("Enter Cnic number: ");
            cnic = Validations.check_if_input_include_special_char(',');
            Console.Write("Enter phone no:  ");
            phone_no = Validations.check_if_input_include_special_char(',');
            Console.Write("Enter Room no: ");
            room_no = Validations.check_if_input_include_special_char(',');
            Console.Write("Enter date of joining(dd/mm/yy): ");
            date_of_joining = Validations.check_if_input_include_special_char(',');

            // Assigining values
            user_to_return.Cnic = cnic;
            user_to_return.Phone_no = phone_no;
            user_to_return.Room_registered = Room_DL.get_room_from_room_no(room_no);
            user_to_return.Date_of_joining = date_of_joining;
            user_to_return.Rent_charged = Room_DL.get_room_from_room_no(room_no).Rent_per_head;

            // Returning object
            return user_to_return;
        }




        // Payable for User
        public static void show_payable_for_user(User user_to_show_payable)
        {
            Program_UI.clear_screen();
            Console.WriteLine($"Your payable this month:     {user_to_show_payable.get_total_payable()}");
            Console.WriteLine($"Your pending payment:        {user_to_show_payable.Pending_payment}\n");
            Console.WriteLine($"Your total payable:          {user_to_show_payable.Pending_payment + user_to_show_payable.get_total_payable()}");
            Program_UI.pause();
        }




        // Show user info
        public static void user_info(User user_to_show)
        {
            Program_UI.clear_screen();
            Console.WriteLine("  Your Information: ");
            Console.WriteLine($"Username:          {user_to_show.Username}");
            Console.WriteLine($"Password:          {user_to_show.Password}");
            Console.WriteLine($"Phone number:      {user_to_show.Phone_no}");
            Console.WriteLine($"Rent:              {user_to_show.Rent_charged}");
            Console.WriteLine($"Food charges:      {user_to_show.Subscribed_food_plan.get_total_price()}");
            Console.WriteLine($"CNIC:              {user_to_show.Cnic}");
            Console.WriteLine($"Room no:           {user_to_show.Room_registered.Room_no}");
            Console.WriteLine($"Joining Date:      {user_to_show.Date_of_joining}");

            Program_UI.pause();
        }



        // Submit Complain
        public static void submit_complain(User user_complaining)
        {
            Program_UI.clear_screen();
            string complain;
            Console.WriteLine("\n\nEnter your complain below: ");
            complain = Validations.check_if_input_include_special_char(',');

            user_complaining.Complain = complain;

            Console.WriteLine("Your complain has been successfully sent.");
            Program_UI.pause();
        }


        // Select food plan
        public static void select_food_plan(User user_to_select_plan)
        {
            Program_UI.clear_screen();
            string plan_name;
            Console.WriteLine("Enter 0 to return.\n\n");
            Food_plan_UI.show_food_plans();

            Console.Write("Enter plan name:  ");
            plan_name = Validations.check_if_input_include_special_char(',');

            if (Food_plan_DL.get_food_plan_from_name(plan_name) != null)
            {
                user_to_select_plan.Subscribed_food_plan = Food_plan_DL.get_food_plan_from_name(plan_name);
                Console.WriteLine("Plan successfully subscribed.");
            }
            else
            {
                if(plan_name == "0")
                {
                    return;
                }
                Console.WriteLine("Please enter a valid plan name.");
                select_food_plan(user_to_select_plan);
                return;
            }

            Program_UI.pause();
        }




        // Un-subscribe Food Plan
        public static void un_subscribe_food_plan(User user_to_unsusbcribe)
        {
            Program_UI.clear_screen();
            string option ="";
            Console.WriteLine("Are you sre you want to un-subscribe your food plan?\n");
            Console.WriteLine("0. No(return)");
            Console.WriteLine("1. Yes");

            Console.Write("Enter option:  ");
            option = Validations.check_if_input_include_special_char(',');

            if(option == "0")
            {
                return;
            }
            else if(option == "1")
            {
                user_to_unsusbcribe.Subscribed_food_plan = null;
                Console.WriteLine("Plan successfully un-subscribed.");
            }
            else
            {
                Console.WriteLine("Please enter a valid option.");
                un_subscribe_food_plan(user_to_unsusbcribe);
                return;
            }

            Program_UI.pause();
        }



        // View user's room details
        public static void user_room_details(User user_to_show_room_details)
        {
            Program_UI.clear_screen();
            Console.WriteLine("  Your Room details\n\n");
            Room_UI.specific_room_details(user_to_show_room_details.Room_registered);
            Console.WriteLine("Registered users for this room includes you also.");
            Program_UI.pause();
        }



        // Shows Registered Users
        public static void show_registered_user()
        {
            Console.WriteLine("Username           Room no            Cnic           Phone no          Rent \n");
            foreach(User user_of_iteration in Person_DL.registered_person)
            {
                Console.WriteLine($"{user_of_iteration.Username}           {user_of_iteration.Room_registered.Room_no}            {user_of_iteration.Cnic}           {user_of_iteration.Phone_no}          {user_of_iteration.Rent_charged}");
            }
        }










    }
}
