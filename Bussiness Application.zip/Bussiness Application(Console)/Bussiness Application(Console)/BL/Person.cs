﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Console_.BL
{
    public class Person
    {
        // Attributes

        protected string username;
        protected string password;
        protected string date_of_joining;
        protected string cnic;
        protected string phone_no;

        // Override attributes for user



        // Constructor

        public Person(string username, string password)
        {
            this.username = username;
            this.password = password;
        }

        public Person()
        {

        }

        // Getter Setter

        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public string Date_of_joining { get => date_of_joining; set => date_of_joining = value; }
        public string Cnic { get => cnic; set => cnic = value; }
        public string Phone_no { get => phone_no; set => phone_no = value; }
    }
}
