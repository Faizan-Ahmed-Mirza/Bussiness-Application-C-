﻿using Bussiness_Application;
using Bussiness_Application.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Console_.BL
{
    public class Owner : Person
    {
        public Owner()
        {

        }

        public Owner(string username, string password) : base(username, password)
        {

        }

        public static double get_total_income()
        {
            double total_income = 0;
            if (Person_DL.registered_person != null)
            {
                foreach (User client in Person_DL.registered_person)
                {
                    total_income = total_income + client.get_total_payable();
                }
            }

            return total_income;
        }
    }
}
