﻿using Bussiness_Application.BL;
using Bussiness_Application_Console_.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application
{
    public class User : Person
    {
        // Attributes
        private string complain;
        private double rent_charged;
        private double gas_bill;
        private double electric_bill;
        private double water_bill;
        private double pending_payment;
        private double net_surplus;
        private Food_plan subscribed_food_plan;
        private Room room_registered;


        // Constructors

        public User()
        {
            this.pending_payment = 0;
            this.net_surplus = 0;
            this.electric_bill = 1000;
            this.water_bill = 300;
            this.gas_bill = 500;
        }

        public User(string username, string password)
        {
            this.username = username;
            this.password = password;
            this.pending_payment = 0;
            this.net_surplus = 0;
            this.electric_bill = 1000;
            this.water_bill = 300;
            this.gas_bill = 500;
        }


        // Getter Setter

        public double Pending_payment { get => pending_payment; set => pending_payment = value; }
        public double Electric_bill { get => electric_bill; set => electric_bill = value; }
        public double Gas_bill { get => gas_bill; set => gas_bill = value; }
        public string Complain { get => complain; set => complain = value; }
        public double Water_bill { get => water_bill; set => water_bill = value; }
        public double Rent_charged { get => rent_charged; set => rent_charged = value; }
        public double Net_surplus { get => net_surplus; set => net_surplus = value; }
        public Food_plan Subscribed_food_plan { get => subscribed_food_plan; set => subscribed_food_plan = value; }
        public Room Room_registered { get => room_registered; set => room_registered = value; }

        // User behaviours


        // Change username password
        public void change_username_passowrd(string new_username, string new_password)
        {
            this.username = new_username;
            this.password = new_password;
        }


        // Get total payable
        public double get_total_payable()
        {
            double total_payable = 0;
            total_payable = this.rent_charged + this.pending_payment + this.electric_bill + this.subscribed_food_plan.get_total_price() + this.gas_bill + this.water_bill + this.net_surplus;
            return total_payable;
        }



        // Get current month payable
        public double get_current_month_payable()
        {
            double current_month_payable = 0;
            current_month_payable = this.rent_charged + this.electric_bill + this.gas_bill + this.water_bill + this.subscribed_food_plan.get_total_price();
            return current_month_payable;
        }


    }
}
