﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.BL
{
    public class Room
    {
        // Attributes
        private string room_no;
        private int client_space;
        private double rent_per_head;
        private bool is_ac_available;
        private bool is_tv_available;
        private bool is_free_or_occupied;
        public List<string> clients_in_room = new List<string>();


        // Constructor(s)
        public Room()
        {

        }

        public Room(string room_no, int client_space, double rent_per_head, bool is_ac_available, bool is_tv_available, bool is_free_or_occupied)
        {
            this.room_no = room_no;
            this.client_space = client_space;
            this.rent_per_head = rent_per_head;
            this.is_ac_available = is_ac_available;
            this.is_tv_available = is_tv_available;
            this.is_free_or_occupied = is_free_or_occupied;
        }


        // Getter Setter
        public string Room_no { get => room_no; set => room_no = value; }
        public int Client_space { get => client_space; set => client_space = value; }
        public double Rent_per_head { get => rent_per_head; set => rent_per_head = value; }
        public bool Is_ac_available { get => is_ac_available; set => is_ac_available = value; }
        public bool Is_tv_available { get => is_tv_available; set => is_tv_available = value; }
        public bool Is_free_or_occupied { get => is_free_or_occupied; set => is_free_or_occupied = value; }


        // Functions
        public void add_client_to_room(string client_name)
        {
            this.clients_in_room.Add(client_name);
        }

        public void remove_client_from_room(string client_name)
        {
            this.clients_in_room.Remove(client_name);
        }

        public int get_space_left()
        {
            return (client_space - this.clients_in_room.Count);
        }
    }
}
