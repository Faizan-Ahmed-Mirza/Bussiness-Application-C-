﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Console_.BL
{
    public class Food_plan
    {
        // Attributes
        private string name;
        private Food_item break_fast;
        private Food_item lunch;
        private Food_item dinner;


        // Constructors
        public Food_plan(string food_plan_name, Food_item break_fast, Food_item lunch, Food_item dinner)
        {
            this.name = food_plan_name;
            this.break_fast = break_fast;
            this.lunch = lunch;
            this.dinner = dinner;
        }

        public Food_plan()
        {

        }


        // Getter Setter
        public Food_item Break_fast { get => break_fast; set => break_fast = value; }
        public Food_item Lunch { get => lunch; set => lunch = value; }
        public Food_item Dinner { get => dinner; set => dinner = value; }
        public string Name { get => name; set => name = value; }


        // function
        public double get_total_price()
        {
            double total_price;
            total_price = this.break_fast.Price + this.lunch.Price + this.dinner.Price;
            return total_price;
        }
    }
}
