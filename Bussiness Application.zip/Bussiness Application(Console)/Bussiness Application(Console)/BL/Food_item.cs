﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Console_.BL
{
    public class Food_item
    {
        // Attributes
        private string name;
        private double price;

        // Getter Setter
        public string Name { get => name; set => name = value; }
        public double Price { get => price; set => price = value; }
    }
}
