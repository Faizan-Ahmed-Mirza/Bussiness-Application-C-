﻿using Bussiness_Application.BL;
using Bussiness_Application_Console_.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.DL
{
    public class Person_DL
    {
        // List
        public static List<Person> registered_person = new List<Person>();
        public static List<Person> un_verified_persons = new List<Person>();

        // functions


        // Add to registered person list
        public static void add_user_to_list(Person person_to_add)
        {
            registered_person.Add(person_to_add);
        }


        // Add to un-verified list
        public static void add_un_verified_person_to_list(Person person_to_add)
        {
            un_verified_persons.Add(person_to_add);
        }


        // Remove verified person
        public static void remove_verified_person(Person person_to_remove)
        {
            registered_person.Remove(person_to_remove);
        }


        // Remove un-verified person
        public static void remove_un_verified_person(Person person_to_remove)
        {
            un_verified_persons.Remove(person_to_remove);
        }



        // Get verified person from username and password(sign in)
        public static Person get_registered_person(string username, string password)
        {
            foreach (Person person_of_iteration in registered_person)
            {
                if ((person_of_iteration.Username == username) && (person_of_iteration.Password == password))
                {
                    return person_of_iteration;
                }
            }

            // If person is not in list
            return null;
        }


        // Get un-verifeid person from username and password
        public static Person get_un_verified_person(string username, string password)
        {
            foreach (Person person_of_iteration in un_verified_persons)
            {
                if ((person_of_iteration.Username == username) && (person_of_iteration.Password == password))
                {
                    return person_of_iteration;
                }
            }

            return null;
        }


        // Check username uniqueness
        public static bool Is_username_unique(string username_to_check)
        {
            foreach (Person person_of_iteration in registered_person)
            {
                if (person_of_iteration.Username == username_to_check)
                {
                    return false;
                }
            }

            foreach (Person person_of_iteration in un_verified_persons)
            {
                if (person_of_iteration.Username == username_to_check)
                {
                    return false;
                }
            }

            return true;
        }





        // Shift a person from un-verified status to registered
        public static void promote_to_registered(Person person_to_promote)
        {
            registered_person.Add(person_to_promote);
            un_verified_persons.Remove(person_to_promote);
        }


        // get registered user from username
        public static User get_registered_user_from_username(string username)
        {
            foreach (User user_of_iteration in registered_person)
            {
                if (user_of_iteration.Username == username)
                {
                    return user_of_iteration;
                }
            }

            return null;
        }





        // get un-verified user from username
        public static User get_un_verified_user_from_username(string username)
        {
            foreach (User user_of_iteration in un_verified_persons)
            {
                if (user_of_iteration.Username == username)
                {
                    return user_of_iteration;
                }
            }

            return null;
        }




        // Set common bills for everyone
        public static void set_common_bill(double electric, double water, double gas)
        {
            foreach (User user_of_iteration in registered_person)
            {
                user_of_iteration.Electric_bill = electric;
                user_of_iteration.Water_bill = water;
                user_of_iteration.Gas_bill = gas;
            }
        }




        // Store verified persons
        public static void store_registered_persons()
        {
            string path = "C:\\Users\\AIMS TECH\\Desktop\\Data\\Verified_Persons.txt";
            StreamWriter file_writer = new StreamWriter(path);
            User user_to_store = new User();
            Owner owner_to_add = new Owner();

            foreach (Person person_of_iteration in registered_person)
            {
                if (person_of_iteration is User)
                {
                    user_to_store = (User)person_of_iteration;
                    file_writer.Write($"client,{person_of_iteration.Username},{person_of_iteration.Password},{person_of_iteration.Cnic},{person_of_iteration.Phone_no},{person_of_iteration.Date_of_joining},");
                    file_writer.Write($"{user_to_store.Electric_bill},{user_to_store.Water_bill},{user_to_store.Gas_bill},{user_to_store.Rent_charged},{user_to_store.Room_registered.Room_no},{user_to_store.Pending_payment},");
                    file_writer.Write($"{user_to_store.Net_surplus},{user_to_store.Subscribed_food_plan.Name},{user_to_store.Complain}");
                    file_writer.WriteLine();
                }
                else if (person_of_iteration is Owner)
                {
                    file_writer.WriteLine($"admin,{person_of_iteration.Username},{person_of_iteration.Password},{person_of_iteration.Cnic},{person_of_iteration.Phone_no},{person_of_iteration.Date_of_joining}");
                }
            }
            file_writer.Close();
        }






        // Store  un verified persons
        public static void store_un_verified_persons()
        {
            string path = "C:\\Users\\AIMS TECH\\Desktop\\Data\\Un_verified_persons.txt";
            StreamWriter file_writer = new StreamWriter(path);
            User user_to_store = new User();
            Owner owner_to_add = new Owner();

            foreach (Person person_of_iteration in un_verified_persons)
            {
                if (person_of_iteration is User)
                {
                    user_to_store = (User)person_of_iteration;
                    file_writer.Write($"client,{person_of_iteration.Username},{person_of_iteration.Password},{person_of_iteration.Cnic},{person_of_iteration.Phone_no},{person_of_iteration.Date_of_joining},");
                    file_writer.Write($"{user_to_store.Electric_bill},{user_to_store.Water_bill},{user_to_store.Gas_bill},{user_to_store.Rent_charged},{user_to_store.Room_registered.Room_no},{user_to_store.Pending_payment},");
                    file_writer.Write($"{user_to_store.Net_surplus},{user_to_store.Subscribed_food_plan.Name},{user_to_store.Complain}");
                    file_writer.WriteLine();
                }
                else if (person_of_iteration is Owner)
                {
                    file_writer.WriteLine($"admin,{person_of_iteration.Username},{person_of_iteration.Password},{person_of_iteration.Cnic},{person_of_iteration.Phone_no},{person_of_iteration.Date_of_joining}");
                }
            }
            file_writer.Close();
        }







        // Load verified persons
        public static void load_registered_persons()
        {
            string line;
            string path = "C:\\Users\\AIMS TECH\\Desktop\\Data\\Verified_Persons.txt";
            if (File.Exists(path))
            {
                User user_to_add = new User();
                Owner owner_to_add = new Owner();
                StreamReader file_reader = new StreamReader(path);
                while ((line = file_reader.ReadLine()) != null)
                {
                    if (Validations.get_field(1, ',', line) == "admin")
                    {
                        owner_to_add.Username = Validations.get_field(2, ',', line);
                        owner_to_add.Password = Validations.get_field(3, ',', line);
                        owner_to_add.Cnic = Validations.get_field(4, ',', line);
                        owner_to_add.Phone_no = Validations.get_field(5, ',', line);
                        owner_to_add.Date_of_joining = Validations.get_field(6, ',', line);
                        registered_person.Add(owner_to_add);

                    }
                    else if (Validations.get_field(1, ',', line) == "client")
                    {
                        user_to_add.Username = Validations.get_field(2, ',', line);
                        user_to_add.Password = Validations.get_field(3, ',', line);
                        user_to_add.Cnic = Validations.get_field(4, ',', line);
                        user_to_add.Phone_no = Validations.get_field(5, ',', line);
                        user_to_add.Date_of_joining = Validations.get_field(6, ',', line);
                        user_to_add.Electric_bill = double.Parse(Validations.get_field(7, ',', line));
                        user_to_add.Water_bill = double.Parse(Validations.get_field(8, ',', line));
                        user_to_add.Gas_bill = double.Parse(Validations.get_field(9, ',', line));
                        user_to_add.Rent_charged = double.Parse(Validations.get_field(10, ',', line));
                        user_to_add.Room_registered = Room_DL.get_room_from_room_no(Validations.get_field(11, ',', line));
                        user_to_add.Pending_payment = double.Parse(Validations.get_field(12, ',', line));
                        user_to_add.Net_surplus = double.Parse(Validations.get_field(13, ',', line));
                        user_to_add.Subscribed_food_plan = Food_plan_DL.get_food_plan_from_name(Validations.get_field(14, ',', line));
                        user_to_add.Complain = Validations.get_field(15, ',', line);
                        registered_person.Add(user_to_add);
                    }
                }

                file_reader.Close();
            }
        }






        // Load un-verified persons
        public static void load_un_verified_persons()
        {
            string line;
            string path = "C:\\Users\\AIMS TECH\\Desktop\\Data\\Un_verified_persons.txt";
            if (File.Exists(path))
            {
                User user_to_add = new User();
                Owner owner_to_add = new Owner();
                StreamReader file_reader = new StreamReader(path);
                while ((line = file_reader.ReadLine()) != null)
                {
                    if (Validations.get_field(1, ',', line) == "admin")
                    {
                        owner_to_add.Username = Validations.get_field(2, ',', line);
                        owner_to_add.Password = Validations.get_field(3, ',', line);
                        owner_to_add.Cnic = Validations.get_field(4, ',', line);
                        owner_to_add.Phone_no = Validations.get_field(5, ',', line);
                        owner_to_add.Date_of_joining = Validations.get_field(6, ',', line);
                        un_verified_persons.Add(owner_to_add);

                    }
                    else if (Validations.get_field(1, ',', line) == "client")
                    {
                        user_to_add.Username = Validations.get_field(2, ',', line);
                        user_to_add.Password = Validations.get_field(3, ',', line);
                        user_to_add.Cnic = Validations.get_field(4, ',', line);
                        user_to_add.Phone_no = Validations.get_field(5, ',', line);
                        user_to_add.Date_of_joining = Validations.get_field(6, ',', line);
                        user_to_add.Electric_bill = double.Parse(Validations.get_field(7, ',', line));
                        user_to_add.Water_bill = double.Parse(Validations.get_field(8, ',', line));
                        user_to_add.Gas_bill = double.Parse(Validations.get_field(9, ',', line));
                        user_to_add.Rent_charged = double.Parse(Validations.get_field(10, ',', line));
                        user_to_add.Room_registered = Room_DL.get_room_from_room_no(Validations.get_field(11, ',', line));
                        user_to_add.Pending_payment = double.Parse(Validations.get_field(12, ',', line));
                        user_to_add.Net_surplus = double.Parse(Validations.get_field(13, ',', line));
                        user_to_add.Subscribed_food_plan = Food_plan_DL.get_food_plan_from_name(Validations.get_field(14, ',', line));
                        user_to_add.Complain = Validations.get_field(15, ',', line);
                        un_verified_persons.Add(user_to_add);
                    }
                }

                file_reader.Close();
            }
        }




    }
}
