﻿using Bussiness_Application.BL;
using Bussiness_Application_Console_.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.DL
{
    public class Food_plan_DL
    {
        // List
        public static List<Food_plan> food_plans_available = new List<Food_plan>();


        // Add food plan to list
        public static void add_food_plan_to_list(Food_plan plan_to_add)
        {
            food_plans_available.Add(plan_to_add);
        }


        // Remove food plan from list
        public static void remove_foodplan_from_list(Food_plan plan_to_remove)
        {
            food_plans_available.Remove(plan_to_remove);
        }


        // Get food plan from name
        public static Food_plan get_food_plan_from_name(string plan_name)
        {
            foreach (Food_plan plan_of_iteration in food_plans_available)
            {
                if (plan_of_iteration.Name == plan_name)
                {
                    return plan_of_iteration;
                }
            }

            return null;
        }



        // is name unique
        public static bool is_plan_name_unique(string plan_name)
        {
            foreach (Food_plan plan_of_iteration in food_plans_available)
            {
                if (plan_of_iteration.Name == plan_name)
                {
                    return false;
                }
            }

            return true;
        }



        // Store 
        public static void store_plans()
        {
            string path = "C:\\Users\\AIMS TECH\\Desktop\\Data\\Food_plans.txt";
            StreamWriter file_writer = new StreamWriter(path);

            foreach (Food_plan plan_of_iteration in food_plans_available)
            {
                file_writer.WriteLine($"{plan_of_iteration.Name},{plan_of_iteration.Break_fast.Name},{plan_of_iteration.Break_fast.Price},{plan_of_iteration.Lunch.Name},{plan_of_iteration.Lunch.Price},{plan_of_iteration.Dinner.Name},{plan_of_iteration.Dinner.Price}");
            }
            file_writer.Close();
        }




        // Load
        public static void load_plans()
        {
            string line;
            string path = "C:\\Users\\AIMS TECH\\Desktop\\Data\\Food_plans.txt";
            if (File.Exists(path))
            {
                Food_plan plan_to_add = new Food_plan();
                StreamReader file_reader = new StreamReader(path);
                while ((line = file_reader.ReadLine()) != null)
                {
                    plan_to_add.Name = Validations.get_field(1, ',', line);
                    plan_to_add.Break_fast.Name = Validations.get_field(2, ',', line);
                    plan_to_add.Break_fast.Price = double.Parse(Validations.get_field(3, ',', line));
                    plan_to_add.Lunch.Name = Validations.get_field(4, ',', line);
                    plan_to_add.Lunch.Price = double.Parse(Validations.get_field(5, ',', line));
                    plan_to_add.Dinner.Name = Validations.get_field(6, ',', line);
                    plan_to_add.Dinner.Price = double.Parse(Validations.get_field(7, ',', line));
                    food_plans_available.Add(plan_to_add);
                }

                file_reader.Close();
            }
        }





    }
}
