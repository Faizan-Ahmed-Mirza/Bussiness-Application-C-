﻿using Bussiness_Application.BL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application.DL
{
    public class Room_DL
    {
        // Rooms list
        public static List<Room> rooms_list = new List<Room>();

        // Add room to list
        public static void add_room_to_list(Room room_to_add)
        {
            rooms_list.Add(room_to_add);
        }

        // Remove room to list
        public static void remove_room_from_list(Room room_to_remove)
        {
            rooms_list.Remove(room_to_remove);
        }

        // Is room no unique?
        public static bool is_room_no_unique(string room_no)
        {
            foreach (Room room_of_iteration in rooms_list)
            {
                if (room_of_iteration.Room_no == room_no)
                {
                    return false;
                }
            }
            return true;
        }


        // Get room from room no
        public static Room get_room_from_room_no(string room_no)
        {
            foreach (Room room_of_iteration in rooms_list)
            {
                if (room_of_iteration.Room_no == room_no)
                {
                    return room_of_iteration;
                }

            }

            return null;
        }




        // Store 
        public static void store_rooms()
        {
            string path = "C:\\Users\\AIMS TECH\\Desktop\\Data\\Room_data.txt";
            StreamWriter file_writer = new StreamWriter(path);
            string tv_availability;
            string ac_availability;

            foreach (Room room_of_iteration in rooms_list)
            {
                if (room_of_iteration.Is_tv_available)
                {
                    tv_availability = "tv_yes";
                }
                else
                {
                    tv_availability = "tv_no";
                }
                if (room_of_iteration.Is_ac_available)
                {
                    ac_availability = "ac_yes";
                }
                else
                {
                    ac_availability = "ac_no";
                }
                file_writer.Write($"{room_of_iteration.Room_no},{room_of_iteration.Client_space},{room_of_iteration.Rent_per_head},{ac_availability},{tv_availability},{room_of_iteration.clients_in_room.Count}");
                for (int i = 0; i < room_of_iteration.clients_in_room.Count; i++)
                {
                    file_writer.Write($",{room_of_iteration.clients_in_room[i]}");
                }
                Console.WriteLine();
            }

            file_writer.Close();
        }








        // Load
        public static void load_rooms()
        {
            string path = "C: \\Users\\AIMS TECH\\Desktop\\Data\\Room_data.txt";
            if (File.Exists(path))
            {
                string line;
                string tv_availability;
                string ac_availability;
                Room room_to_add = new Room();

                StreamReader file_reader = new StreamReader(path);
                while ((line = file_reader.ReadLine()) != null)
                {
                    room_to_add.Room_no = Validations.get_field(1, ',', line);
                    room_to_add.Client_space = int.Parse(Validations.get_field(2, ',', line));
                    room_to_add.Rent_per_head = double.Parse(Validations.get_field(3, ',', line));
                    ac_availability = Validations.get_field(4, ',', line);
                    tv_availability = (Validations.get_field(5, ',', line));
                    for (int i = 0; i < int.Parse(Validations.get_field(6, ',', line)); i++)
                    {
                        room_to_add.clients_in_room.Add(Validations.get_field(6 + i, ',', line));
                    }
                    if (tv_availability == "tv_yes")
                    {
                        room_to_add.Is_tv_available = true;
                    }
                    else
                    {
                        room_to_add.Is_tv_available = false;
                    }

                    if (ac_availability == "ac_yes")
                    {
                        room_to_add.Is_ac_available = true;
                    }
                    else
                    {
                        room_to_add.Is_ac_available = false;
                    }

                    rooms_list.Add(room_to_add);
                }

                file_reader.Close();
            }
        }


    }
}
