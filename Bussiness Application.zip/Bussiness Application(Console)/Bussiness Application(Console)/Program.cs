﻿using Bussiness_Application;
using Bussiness_Application.DL;
using Bussiness_Application.UI;
using Bussiness_Application_Console_.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application_Console_
{
    class Program
    {
        static void Main(string[] args)
        {
            // Load

            Program_UI.load_data();

            // Default admin

            if (Person_DL.registered_person.Count == 0)
            {
                Owner default_admin = new Owner("admin", "123");
                Person_DL.registered_person.Add(default_admin);
            }

            // Header
            Program_UI.header();

            // Login person and option variables 
            Person logged_in_person = new Person();
            string option = "";
            string logged_in_person_option = "";


            // Program loop
            while (option != "3")
            {
                option = Program_UI.mainmenu();
                if (option == "1")
                {
                    Program_UI.Sign_up();
                }
                else if (option == "2")
                {
                    logged_in_person = Program_UI.Sign_in();

                    // Checking if user exists
                    if (logged_in_person != null)
                    {

                        // Client login
                        if (logged_in_person is User)
                        {
                            logged_in_person_option = User_UI.User_menu((User)logged_in_person);

                            if (logged_in_person_option == "0")
                            {
                                continue;
                            }
                            else if (logged_in_person_option == "1")
                            {
                                Room_UI.show_available_rooms();
                            }
                            else if (logged_in_person_option == "2")
                            {
                                User_UI.select_food_plan((User)logged_in_person);
                            }
                            else if (logged_in_person_option == "3")
                            {
                                User_UI.un_subscribe_food_plan((User)logged_in_person);
                            }
                            else if (logged_in_person_option == "4")
                            {
                                User_UI.show_payable_for_user((User)logged_in_person);
                            }
                            else if (logged_in_person_option == "5")
                            {
                                User_UI.submit_complain((User)logged_in_person);
                            }
                            else if (logged_in_person_option == "6")
                            {
                                Person_UI.change_password(logged_in_person);
                            }
                            else if (logged_in_person_option == "7")
                            {
                                User_UI.user_info((User)logged_in_person);
                            }
                            else if (logged_in_person_option == "8")
                            {
                                User_UI.user_room_details((User)logged_in_person);
                            }
                            else if (logged_in_person_option == "9")
                            {
                                Person_UI.delete_account(logged_in_person);
                            }
                            else if (logged_in_person_option == "10")
                            {
                                // Store data
                                Program_UI.store_data();
                                Environment.Exit(0);
                            }
                        }


                        // Owner login

                        else if (logged_in_person is Owner)
                        {
                        Admin_Menu:
                            logged_in_person_option = Owner_UI.admin_menu((Owner)logged_in_person);

                            if (option == "0")
                            {
                                continue;
                            }
                            else if (logged_in_person_option == "1")
                            {
                                Room_UI.show_available_rooms();
                            }
                            else if (logged_in_person_option == "2")
                            {
                                Owner_UI.add_new_client();
                            }
                            else if (logged_in_person_option == "3")
                            {
                                Room_UI.add_new_room();
                            }
                            else if (logged_in_person_option == "4")
                            {
                                Food_plan_UI.add_new_food_plan();
                            }
                            else if (logged_in_person_option == "5")
                            {
                                Owner_UI.impose_fine();
                            }
                            else if (logged_in_person_option == "6")
                            {
                                Owner_UI.mark_discount();
                            }
                            else if (logged_in_person_option == "7")
                            {
                                Owner_UI.edit_client_details();
                            }
                            else if (logged_in_person_option == "8")
                            {
                                Room_UI.edit_room_details();
                            }
                            else if (logged_in_person_option == "9")
                            {
                                Food_plan_UI.edit_food_plan();
                            }
                            else if (logged_in_person_option == "10")
                            {
                                Owner_UI.see_total_payable_of_a_client();
                            }
                            else if (logged_in_person_option == "11")
                            {
                                Owner_UI.view_pending_approvals_panal();
                            }
                            else if (logged_in_person_option == "12")
                            {
                                Owner_UI.view_complain();
                            }
                            else if (logged_in_person_option == "13")
                            {
                                Person_UI.set_common_bill();
                            }
                            else if (logged_in_person_option == "14")
                            {
                                Owner_UI.clear_add_pending_of_client();
                            }
                            else if (logged_in_person_option == "15")
                            {
                                Owner_UI.view_total_income();
                            }
                            else if (logged_in_person_option == "16")
                            {
                                Owner_UI.remove_a_client();
                            }
                            else if (logged_in_person_option == "17")
                            {
                                // Store data
                                Program_UI.store_data();
                                Environment.Exit(0);
                            }
                            else
                            {
                                Console.WriteLine("Please enter a valid option.");
                                Program_UI.pause();
                                goto Admin_Menu;
                            }
                        }
                    }
                }
            }
        }
    }
}
